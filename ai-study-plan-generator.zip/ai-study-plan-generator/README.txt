AI Study Plan Generator

Open index.html in Chrome, Edge or Firefox. No internet, server or API key needed.
